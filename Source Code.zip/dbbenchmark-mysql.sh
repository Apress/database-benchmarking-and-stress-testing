#!/bin/bash

#==============================================================================================================

function usage () {

echo ""
echo "==================================================================="
echo "Usage: `basename $0` -h -u -p -d -z -s -S -i -r -P"
echo "==================================================================="
echo ""
# banner message (do not change)
echo "CREDITS: utility for testing database performance by Bert Scalzo"
echo ""
echo "OPTIONS:"
echo "    -h    Help           (print this help information)   --DEFAULTS--"
echo "    -u    Username       Database username               ($DB_USERNAME)"
echo "    -p    Password       Database password               ($DB_PASSWORD)"
echo "    -d    Database       Database db name                ($DB_DATABASE)"
echo "    -z    Test Size      Values: SMALL, MEDIUM, LARGE    ($TEST_SIZE)"
echo "    -s    Session Start  Beginning user session count    ($SESSION_START)"
echo "    -S    Session Stop   Ending user session count       ($SESSION_STOP)"
echo "    -i    Increment by   Increment session count by      ($SESSION_INCR)"
echo "    -r    Run Time       Run Time in Seconds             ($RUN_TIME)"
echo "    -P    Plot Data      Plot graphs of SAR data: Y/N    ($PLOT_DATA)"
echo ""
echo "==================================================================="
echo ""

}

#==============================================================================================================

function set_defaults () {

# define parameter defaults
DB_USERNAME=""
DB_PASSWORD=""
DB_DATABASE=""
TEST_SIZE="SMALL"
SESSION_START=1
SESSION_STOP=10
SESSION_INCR=1
RUN_TIME=30
PLOT_DATA="Y"

# define test run defaults
SIZE_SMALL=10000
SIZE_MEDIUM=100000
SIZE_LARGE=1000000

# define database defaults
COL_LENGTH=128
BATCH_SIZE=1

# define command interpreter
CMD_TOOL="mysql"
PLOT_TOOL="gnuplot"
SQL_CMD="$CMD_TOOL -u$DB_USERNAME -p$DB_PASSWORD $DB_DATABASE"

# define all constant (non-loop) report names

NOW=$(date +"%Y.%m.%d_%H.%M.%S")

REPORT_DIR="DBBENCHMARK_"$NOW
REPORT_NAME="DBBENCHMARK_"
REPORT_LEAD=$REPORT_DIR"/"$REPORT_NAME

# sar -b (block devices)
REPORT_IO_LOG=$REPORT_LEAD"_SAR_AVERGAGE_IO.log"
REPORT_IO_TMP=$REPORT_LEAD"_SAR_AVERGAGE_IO.tmp"
REPORT_IO_JPG=$REPORT_LEAD"_SAR_AVERGAGE_IO.jpg"

# sar -u (CPU)
REPORT_CPU_LOG=$REPORT_LEAD"_SAR_AVERGAGE_CPU.log"
REPORT_CPU_TMP=$REPORT_LEAD"_SAR_AVERGAGE_CPU.tmp"
REPORT_CPU_JPG=$REPORT_LEAD"_SAR_AVERGAGE_CPU.jpg"

# sar -r (RAM)
REPORT_RAM_LOG=$REPORT_LEAD"_SAR_AVERGAGE_RAM.log"
REPORT_RAM_TMP=$REPORT_LEAD"_SAR_AVERGAGE_RAM.tmp"
REPORT_RAM_JPG=$REPORT_LEAD"_SAR_AVERGAGE_RAM.jpg"

# sar -q (Run Queue)
REPORT_QUE_LOG=$REPORT_LEAD"_SAR_AVERGAGE_QUE.log"
REPORT_QUE_TMP=$REPORT_LEAD"_SAR_AVERGAGE_QUE.tmp"
REPORT_QUE_JPG=$REPORT_LEAD"_SAR_AVERGAGE_QUE.jpg"

}

#==============================================================================================================

function show_params () {

# list working values
echo ""
echo "==================================================================="
echo ""
echo "$BANNER"
echo ""
echo "PARAMETERS:"
echo "    DB_USERNAME    = $DB_USERNAME"
echo "    DB_PASSWORD    = $DB_PASSWORD"
echo "    DB_DATABASE    = $DB_DATABASE"
echo "    TEST_SIZE      = $TEST_SIZE (`printf "%'.f" $ROW_CNT` rows / session)"
echo "    SESSION_START  = `printf "%'.f" $SESSION_START`"
echo "    SESSION_STOP   = `printf "%'.f" $SESSION_STOP`"
echo "    SESSION_INCR   = $SESSION_INCR"
echo "    RUN_TIME       = `printf "%'.f" $RUN_TIME` (seconds)"
echo "    PLOT_DATA      = $PLOT_DATA"
echo ""
echo "==================================================================="
echo ""

}

#==============================================================================================================

function test_plot () {
if ( ! type $PLOT_TOOL > /dev/null 2>&1 )
then
    exit 0
else

    exit 1
fi
}

#==============================================================================================================

function test_plot_version () {
PLOT_VER1=`$PLOT_TOOL --version | cut -d\. -f1 | cut -d' ' -f2`
PLOT_VER2=`$PLOT_TOOL --version | cut -d\. -f2 | cut -d' ' -f1`
if [ "$PLOT_VER1" -lt "4" ]
then
    exit 0
else
    if [ "$PLOT_VER2" -lt "2" ]
    then
        exit 0
    else
        exit 1
    fi
fi
}
#==============================================================================================================

function test_command () {
if ( ! type $CMD_TOOL > /dev/null 2>&1 )
then
    exit 0
else
    exit 1
fi
}


#==============================================================================================================

function test_connect () {
SQL_CMD="$CMD_TOOL -L -S $DB_USERNAME/$DB_PASSWORD@$DB_DATABASE"
$SQL_CMD <<EOF > /dev/null 2>&1
show databases;
EOF
return $?
}

#==============================================================================================================

function plot_data () {

gnuplot <<EOF > /dev/null 2>&1
set terminal jpeg
set grid y
set grid x
set key outside

#----------------------------------------------

set title  "DBBENCHMARK: SAR IO Throughput"
set xlabel "# Concurrent Users"
set xrange [-1:*]
set ylabel "Transactions/Second"
set yrange [0:*]

set style data histograms
set style histogram rowstacked
set style fill solid border
set boxwidth .5

set output '$REPORT_IO_JPG'
plot '$REPORT_IO_LOG' u 2:xtic(1) t "read_tps", '' u 3 t "write_tps"

#----------------------------------------------

set title  "DBBENCHMARK: SAR CPU Utilization"
set xlabel "# Concurrent Users"
set xrange [-1:*]
set ylabel "Precent CPU Usage"
set yrange [0:100]

set style data histograms
set style histogram rowstacked
set style fill solid border
set boxwidth .5

set output '$REPORT_CPU_JPG'
plot '$REPORT_CPU_LOG' u 2:xtic(1) t "%user", '' u 3 t "%nice", '' u 4 t "%system", '' u 5 t "%iowait"

#----------------------------------------------

set title  "DBBENCHMARK: SAR RAM Utilization"
set xlabel "# Concurrent Users"
set xrange [-1:*]
set ylabel "Precent RAM Usage"
set yrange [0:100]

set style data histograms
set style histogram
set style fill solid border
set boxwidth .5

set output '$REPORT_RAM_JPG'
plot '$REPORT_RAM_LOG' u 2:xtic(1) t "%mem_used"

#----------------------------------------------

set title  "DBBENCHMARK: SAR RUN QUEUE Utilization"
set xlabel "# Concurrent Users"
set xrange [-1:*]
set ylabel "Run Queue Depth"
set yrange [0:*]

set style data histograms
set style histogram
set style fill solid border
set boxwidth .5

set output '$REPORT_QUE_JPG'
plot '$REPORT_QUE_LOG' u 2:xtic(1) t "run_queue"
EOF

if [ $? -ne 0 ]; then return $?; fi

return $?
}

#==============================================================================================================

function test_results () {

echo ""
echo "==================================================================="
echo ""
echo "RESULTS:"

tail -q -n 1 $REPORT_LEAD*"_SESSIONS_SAR_IO.log" > $REPORT_IO_TMP
awk -v XSTART=$SESSION_START -v XINCR=$SESSION_INCR 'BEGIN{print "#users\t\tread_tps\t\twrite_tps"}{printf "%s\t\t%s\t\t%s\n",XSTART,$3,$4;XSTART+=XINCR}' < $REPORT_IO_TMP 1> $REPORT_IO_LOG 2>/dev/null
rm $REPORT_IO_TMP

tail -q -n 1 $REPORT_LEAD*"_SESSIONS_SAR_CPU.log" > $REPORT_CPU_TMP
awk -v XSTART=$SESSION_START -v XINCR=$SESSION_INCR 'BEGIN{print "#users\t\t%user\t\t%nice\t\t%system\t\t%iowait"}{printf "%s\t\t%s\t\t%s\t\t%s\t\t%s\n",XSTART,$3,$4,$5,$6;XSTART+=XINCR}' < $REPORT_CPU_TMP 1> $REPORT_CPU_LOG 2>/dev/null
rm $REPORT_CPU_TMP

tail -q -n 1 $REPORT_LEAD*"_SESSIONS_SAR_RAM.log" > $REPORT_RAM_TMP
awk -v XSTART=$SESSION_START -v XINCR=$SESSION_INCR 'BEGIN{print "#users\t\t%mem_used"}{printf "%s\t\t%s\n",XSTART,$4;XSTART+=XINCR}' < $REPORT_RAM_TMP 1> $REPORT_RAM_LOG 2>/dev/null
rm $REPORT_RAM_TMP

tail -q -n 1 $REPORT_LEAD*"_SESSIONS_SAR_QUE.log" > $REPORT_QUE_TMP
awk -v XSTART=$SESSION_START -v XINCR=$SESSION_INCR 'BEGIN{print "#users\t\trun_queue"}{printf "%s\t\t%s\n",XSTART,$2;XSTART+=XINCR}' < $REPORT_QUE_TMP 1> $REPORT_QUE_LOG 2>/dev/null
rm $REPORT_QUE_TMP

echo ""
echo $REPORT_IO_LOG
cat  $REPORT_IO_LOG

echo ""
echo $REPORT_CPU_LOG
cat  $REPORT_CPU_LOG

echo ""
echo $REPORT_RAM_LOG
cat  $REPORT_RAM_LOG

echo ""
echo $REPORT_QUE_LOG
cat  $REPORT_QUE_LOG

echo ""
echo "==================================================================="

if [ "$PLOT_DATA" = "Y" ]
then
    plot_data
fi

return $?
}

#==============================================================================================================

function test_init () {

echo "WORKING: ....Create DBBENCHMARK_TEST benchmark data table & load"
$SQL_CMD <<EOF > /dev/null 2>&1
delimiter ;
drop table if exists DBBENCHMARK_TEST;
CREATE TABLE DBBENCHMARK_TEST
(
    sid BIGINT
  , rid BIGINT
  , c01 VARCHAR($COL_LENGTH)
  , c02 VARCHAR($COL_LENGTH)
  , c03 VARCHAR($COL_LENGTH)
  , c04 VARCHAR($COL_LENGTH)
  , c05 VARCHAR($COL_LENGTH)
  , c06 VARCHAR($COL_LENGTH)
  , c07 VARCHAR($COL_LENGTH)
  , c08 VARCHAR($COL_LENGTH)
  , c09 VARCHAR($COL_LENGTH)
  , c10 VARCHAR($COL_LENGTH)
);
drop procedure if exists DBBENCHMARK_LOADDATA;
delimiter //
create procedure DBBENCHMARK_LOADDATA()
BEGIN
DECLARE v_sid  BIGINT default $SESSION_START;
DECLARE v_rid  BIGINT default 1;
DECLARE v_xxx  VARCHAR($COL_LENGTH) default repeat('X',$COL_LENGTH);
DECLARE v_yyy  VARCHAR($COL_LENGTH) default repeat('Y',$COL_LENGTH);
DECLARE v_zzz  VARCHAR($COL_LENGTH) default repeat('Z',$COL_LENGTH);
while (v_sid <= $SESSION_STOP) do
  set v_sid = v_sid + 1;
  while (v_rid <= $ROW_CNT) do
    set v_rid = v_rid + 1;
    INSERT INTO DBBENCHMARK_TEST
        VALUES (v_sid, v_rid,
                v_xxx, v_yyy, v_zzz, v_xxx, v_yyy, v_zzz, v_xxx, v_yyy, v_zzz, v_xxx);
    IF ( MOD( v_rid, 100 ) = 0 ) THEN
        COMMIT;
    END IF;
  end while;
  COMMIT;
end while;
COMMIT;
END
//
delimiter ;
call DBBENCHMARK_LOADDATA;
EOF
if [ $? -ne 0 ]; then return $?; fi

echo "WORKING: ....Create DBBENCHMARK_TEST table's sole non-unique index"
$SQL_CMD <<EOF > /dev/null 2>&1
CREATE INDEX DBBENCHMARK_TEST_IDX1 ON DBBENCHMARK_TEST(sid, rid);
EOF
if [ $? -ne 0 ]; then return $?; fi

echo "WORKING: ....Create DBBENCHMARK_WORKLOAD procedure to execute"
$SQL_CMD <<EOF > /dev/null 2>&1
﻿drop procedure if exists DBBENCHMARK_WORKLOAD;
delimiter //
create procedure DBBENCHMARK_WORKLOAD(in p_sid int, in p_run_time int)
BEGIN
declare v_min      bigint;
declare v_max      bigint;
declare v_chunk    integer default $BATCH_SIZE;
declare v_control  integer;
declare v_trx_cnt  bigint default 0;
declare v_date1    datetime;
declare v_aaa      varchar(128) default repeat('A',$COL_LENGTH);
declare v_bbb      varchar(128) default repeat('B',$COL_LENGTH);
declare v_ccc      varchar(128) default repeat('C',$COL_LENGTH);
declare v_cnt      integer;
set v_date1=NOW();
while TIME_TO_SEC(TIMEDIFF(NOW(),v_date1)) < p_run_time do
    select MIN(rid) into v_min from DBBENCHMARK_TEST where sid=p_sid;
    select MAX(rid) into v_max from DBBENCHMARK_TEST where sid=p_sid;
    set v_control = FLOOR(1+RAND()*8);
    CASE v_control
    WHEN 1 THEN
        UPDATE DBBENCHMARK_TEST SET
            c01 = REPEAT(LOWER(CONV(FLOOR(RAND()*36),10,36)),$COL_LENGTH),
            c10 = REPEAT(LOWER(CONV(FLOOR(RAND()*36),10,36)),$COL_LENGTH)
            WHERE (sid = p_sid and rid = v_min
                   or
                   sid = p_sid and rid = v_max);
        set v_trx_cnt = v_trx_cnt + 1;
    WHEN 2 THEN
        UPDATE DBBENCHMARK_TEST SET
            c01 = REPEAT(LOWER(CONV(FLOOR(RAND()*36),10,36)),$COL_LENGTH),
            c10 = REPEAT(LOWER(CONV(FLOOR(RAND()*36),10,36)),$COL_LENGTH)
            WHERE (sid = p_sid and rid between v_min and v_min+v_chunk
                   or
                   sid = p_sid and rid between v_max-v_chunk and v_max);
        set v_trx_cnt = v_trx_cnt + 1;
    WHEN 3 THEN
        UPDATE DBBENCHMARK_TEST SET
            c01 = REPEAT(LOWER(CONV(FLOOR(RAND()*36),10,36)),$COL_LENGTH),
            c10 = REPEAT(LOWER(CONV(FLOOR(RAND()*36),10,36)),$COL_LENGTH)
            WHERE (sid = p_sid and rid = v_min
                   or
                   sid = p_sid and rid = v_max);
        set v_trx_cnt = v_trx_cnt + 1;
    WHEN 4 THEN
        UPDATE DBBENCHMARK_TEST SET
            c01 = REPEAT(LOWER(CONV(FLOOR(RAND()*36),10,36)),$COL_LENGTH),
            c10 = REPEAT(LOWER(CONV(FLOOR(RAND()*36),10,36)),$COL_LENGTH)
            WHERE (sid = p_sid and rid between v_min and v_min+v_chunk
                   or
                   sid = p_sid and rid between v_max-v_chunk and v_max);
        set v_trx_cnt = v_trx_cnt + 1;
    WHEN 5 THEN
        DELETE FROM DBBENCHMARK_TEST
            WHERE (sid = p_sid and rid = v_min
                   or
                   sid = p_sid and rid = v_max);
        set v_trx_cnt = v_trx_cnt + 1;
    WHEN 6 THEN
        DELETE FROM DBBENCHMARK_TEST
            WHERE (sid = p_sid and rid between v_min and v_min+v_chunk
                   or
                   sid = p_sid and rid between v_max-v_chunk and v_max);
        set v_trx_cnt = v_trx_cnt + 1;
    WHEN 7 THEN
        INSERT INTO DBBENCHMARK_TEST
            VALUES (p_sid, v_min-1,
                    v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa);
        INSERT INTO DBBENCHMARK_TEST
            VALUES (p_sid, v_max+1,
                    v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa);
        set v_trx_cnt = v_trx_cnt + 2;
    WHEN 8 THEN
        set v_cnt=0;
        while v_cnt < v_chunk do
            set v_cnt = v_cnt + 1;
            INSERT INTO DBBENCHMARK_TEST
                VALUES (p_sid, v_min-v_cnt,
                        v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa);
        end while;
        set v_cnt=0;
        while v_cnt < v_chunk do
            set v_cnt = v_cnt + 1;
            INSERT INTO DBBENCHMARK_TEST
                VALUES (p_sid, v_max+v_cnt,
                        v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa);
        end while;
        set v_trx_cnt = v_trx_cnt + (2 * v_chunk);
    END CASE;
    COMMIT;
end while;
commit;
END
//
EOF
if [ $? -ne 0 ]; then return $?; fi

return $?
}

#==============================================================================================================

function test_workload () {
###echo "....call DBBENCHMARK_WORKLOAD($SESSION_CNT,$RUN_TIME)"
$SQL_CMD <<EOF > /dev/null 2>&1
call DBBENCHMARK_WORKLOAD($SESSION_CNT,$RUN_TIME);
EOF
if [ $? -ne 0 ]; then return $?; fi

return $?
}

#==============================================================================================================

function test_start () {
###echo "....resetting MySQL query cache...."
$SQL_CMD <<EOF > /dev/null 2>&1
RESET QUERY CACHE;
EOF
if [ $? -ne 0 ]; then return $?; fi

return $?
}

#==============================================================================================================

function test_stop () {
### Nothing for MySQL
return $?
}

#==============================================================================================================

function test_exec () {

test_start
if [ $? -ne 0 ]; then return $?; fi

sar -b $SAR_INT $SAR_CNT > $REPORT_LEAD"_`printf "%04d" $SESSION_CUR`_SESSIONS_SAR_IO.log" &
sar -u $SAR_INT $SAR_CNT > $REPORT_LEAD"_`printf "%04d" $SESSION_CUR`_SESSIONS_SAR_CPU.log" &
sar -r $SAR_INT $SAR_CNT > $REPORT_LEAD"_`printf "%04d" $SESSION_CUR`_SESSIONS_SAR_RAM.log" &
sar -q $SAR_INT $SAR_CNT > $REPORT_LEAD"_`printf "%04d" $SESSION_CUR`_SESSIONS_SAR_QUE.log" &

echo "WORKING: Executing `printf "%'.f" $SESSION_CUR` sessions against DBBENCHMARK_TEST table"
SESSION_CNT=1
while [ $SESSION_CNT -le $SESSION_CUR ]
do
    ( test_workload ) &
    SESSION_CNT=$[$SESSION_CNT+1]
done
echo "WORKING: ....Waiting on `printf "%'.f" $SESSION_CUR` sessions against DBBENCHMARK_TEST table"

wait

test_stop
if [ $? -ne 0 ]; then return $?; fi

return $?
}

#==============================================================================================================

function raise_error () {
echo ""
echo "==================================================================="
echo ""
echo "***ERROR*** $1: $2"
echo ""
echo "==================================================================="
echo ""
}

#==============================================================================================================
#========== Main body
#==============================================================================================================

set_defaults

if [ $# -eq 0 ]
then
    usage
    exit 1
fi

if [ $# -gt 0 ]
then
REQ_PARM_COUNT=0
# process parameters
while getopts "hu:u:p:d:z:s:S:i:r:P:" opt; do
    case $opt in
    h)
        usage
        exit 1
        ;;
    u)
        DB_USERNAME="$OPTARG"
        REQ_PARM_COUNT=$[$REQ_PARM_COUNT+1]
        ;;
    p)
        DB_PASSWORD="$OPTARG"
        REQ_PARM_COUNT=$[$REQ_PARM_COUNT+1]
        ;;
    d)
        DB_DATABASE="$OPTARG"
        REQ_PARM_COUNT=$[$REQ_PARM_COUNT+1]
        ;;
    z)
        TEST_SIZE="$OPTARG"
        ;;
    s)
        SESSION_START="$OPTARG"
        ;;
    S)
        SESSION_STOP="$OPTARG"
        ;;
    i)
        SESSION_INCR="$OPTARG"
        ;;
    r)
        RUN_TIME="$OPTARG"
        ;;
    P)
        PLOT_DATA="$OPTARG"
        ;;
    \?)
        exit 1
        ;;
    esac
done
fi

if [ $REQ_PARM_COUNT -ne 3 ]
then
    raise_error "USAGE" "You must supply user name, password and database"
    exit 1
fi

TEST_SIZE=`echo $TEST_SIZE | tr 'a-z' 'A-Z'`
PLOT_DATA=`echo $PLOT_DATA | tr 'a-z' 'A-Z'`

case $TEST_SIZE in
SMALL)
    ROW_CNT=$SIZE_SMALL
    ;;
MEDIUM)
    ROW_CNT=$SIZE_MEDIUM
    ;;
LARGE)
    ROW_CNT=$SIZE_LARGE
    ;;
esac

# list working values
show_params

if [ "$TEST_SIZE" != "SMALL" -a "$TEST_SIZE" != "MEDIUM" -a "$TEST_SIZE" != "LARGE" ]
then
    raise_error "USAGE" "Test size must be either SMALL or MEDIUM or LARGE"
    exit 1
fi

if [ $SESSION_START -lt 1 ]
then
    raise_error "USAGE" "Sessions start must be >= 1"
    exit 1
fi

if [ $SESSION_STOP -lt $SESSION_START ]
then
    raise_error "USAGE" "Sessions stop must be >= sessions start"
    exit 1
fi

if [ $SESSION_INCR -lt 1 ]
then
    raise_error "USAGE" "Sessions increment by count must be >= 1"
    exit 1
fi

if [ $RUN_TIME -lt 10 ]
then
    raise_error "USAGE" "Run time must be >= 10 (seconds)"
    exit 1
fi

if [ "$PLOT_DATA" != "Y" -a "$PLOT_DATA" != "N" ]
then
    raise_error "USAGE" "Plot graphs of SAR data be either Y or N"
    exit 1
fi
echo "WORKING: Testing for $PLOT_TOOL found executable in current \$PATH"
if ( ! test_plot )
then
    raise_error "ENV-PATH" "$PLOT_TOOL executable not found in current \$PATH"
    exit 1
fi
if ( ! test_plot_version )
then
    raise_error "VERSION" "$PLOT_TOOL disabled since it's version < 4.2"
    PLOT_DATA="N"
fi

echo "WORKING: Testing for $CMD_TOOL found executable in current \$PATH"
if ( ! test_command )
then
    raise_error "ENV-PATH" "$CMD_TOOL executable not found in current \$PATH"
    exit 1
fi

echo "WORKING: Testing connect to database with supplied parameters"
if ( ! test_connect )
then
    raise_error "DATABASE" "Cannot connect successfully to database with supplied parameters"
    exit 1
fi

rm -rf $REPORT_DIR
mkdir $REPORT_DIR

echo "WORKING: Processing steps for running benchmark test"
if ( test_init )
then
    SAR_INT=5
    SAR_CNT=$[($RUN_TIME/$SAR_INT)]
    SESSION_CUR=$SESSION_START
    while [ $SESSION_CUR -le $SESSION_STOP ]
    do
        test_exec
        SESSION_CUR=$[$SESSION_CUR+$SESSION_INCR]
    done
    test_results
    echo ""
    echo "WORKING: Zipping up test report directory and files into one zip file"
    zip $REPORT_DIR".zip" $REPORT_DIR/* > /dev/null 2>&1
fi

echo ""
echo "==================================================================="
echo ""
echo "ALLDONE: Processing successfully completed ..."
echo ""
echo "==================================================================="
echo ""

#==============================================================================================================
