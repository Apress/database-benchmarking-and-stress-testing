#!/bin/bash

#==============================================================================================================

function usage () {

echo ""
echo "==================================================================="
echo "Usage: `basename $0` -h -u -p -d -z -s -S -i -r -P -T -a -b"
echo "==================================================================="
echo ""
# banner message (do not change)
echo "CREDITS: utility for testing database performance by Bert Scalzo"
echo ""
echo "OPTIONS:"
echo "    -h    Help           (print this help information)   --DEFAULTS--"
echo "    -u    Username       Database username               ($DB_USERNAME)"
echo "    -p    Password       Database password               ($DB_PASSWORD)"
echo "    -d    Database       Database db name                ($DB_DATABASE)"
echo "    -z    Test Size      Values: SMALL, MEDIUM, LARGE    ($TEST_SIZE)"
echo "    -s    Session Start  Beginning user session count    ($SESSION_START)"
echo "    -S    Session Stop   Ending user session count       ($SESSION_STOP)"
echo "    -i    Increment by   Increment session count by      ($SESSION_INCR)"
echo "    -r    Run Time       Run Time in Seconds             ($RUN_TIME)"
echo "    -P    Plot Data      Plot graphs of SAR data: Y/N    ($PLOT_DATA)"
echo "    -T    Tablespace     Default tablespace              ($DEF_TSP)"
echo "    -a    AWR Snapshot   Take AWR snapshots: Y/N         ($AWR_SNAP)"
echo "    -b    AWR baseline   Create AWR baseline: Y/N        ($AWR_BASE)"
echo ""
echo "==================================================================="
echo ""

}

#==============================================================================================================

function set_defaults () {

# define parameter defaults
DB_USERNAME=""
DB_PASSWORD=""
DB_DATABASE=""
TEST_SIZE="SMALL"
SESSION_START=1
SESSION_STOP=10
SESSION_INCR=1
RUN_TIME=30
PLOT_DATA="Y"
DEF_TSP="USERS"
AWR_SNAP="N"
AWR_BASE="N"

# define test run defaults
SIZE_SMALL=10000
SIZE_MEDIUM=100000
SIZE_LARGE=1000000

# define database defaults
COL_LENGTH=128
BATCH_SIZE=1

# define command interpreter
CMD_TOOL="sqlplus"
PLOT_TOOL="gnuplot"
SQL_CMD="$CMD_TOOL -L -S $DB_USERNAME/$DB_PASSWORD@$DB_DATABASE"

# define all constant (non-loop) report names

NOW=$(date +"%Y.%m.%d_%H.%M.%S")

REPORT_DIR="DBBENCHMARK_"$NOW
REPORT_NAME="DBBENCHMARK_"
REPORT_LEAD=$REPORT_DIR"/"$REPORT_NAME

# sar -b (block devices)
REPORT_IO_LOG=$REPORT_LEAD"_SAR_AVERGAGE_IO.log"
REPORT_IO_TMP=$REPORT_LEAD"_SAR_AVERGAGE_IO.tmp"
REPORT_IO_JPG=$REPORT_LEAD"_SAR_AVERGAGE_IO.jpg"

# sar -u (CPU)
REPORT_CPU_LOG=$REPORT_LEAD"_SAR_AVERGAGE_CPU.log"
REPORT_CPU_TMP=$REPORT_LEAD"_SAR_AVERGAGE_CPU.tmp"
REPORT_CPU_JPG=$REPORT_LEAD"_SAR_AVERGAGE_CPU.jpg"

# sar -r (RAM)
REPORT_RAM_LOG=$REPORT_LEAD"_SAR_AVERGAGE_RAM.log"
REPORT_RAM_TMP=$REPORT_LEAD"_SAR_AVERGAGE_RAM.tmp"
REPORT_RAM_JPG=$REPORT_LEAD"_SAR_AVERGAGE_RAM.jpg"

# sar -q (Run Queue)
REPORT_QUE_LOG=$REPORT_LEAD"_SAR_AVERGAGE_QUE.log"
REPORT_QUE_TMP=$REPORT_LEAD"_SAR_AVERGAGE_QUE.tmp"
REPORT_QUE_JPG=$REPORT_LEAD"_SAR_AVERGAGE_QUE.jpg"

# Oracle IOPS calculation
REPORT_IOPS1_LOG=$REPORT_LEAD"_ORACLE_IOPS_DETAIL.log"
REPORT_IOPS2_LOG=$REPORT_LEAD"_ORACLE_IOPS_SHORT.log"
REPORT_IOPS2_JPG=$REPORT_LEAD"_ORACLE_IOPS_SHORT.jpg"

}

#==============================================================================================================

function show_params () {

echo ""
echo "==================================================================="
echo ""
echo "$BANNER"
echo ""
echo "PARAMETERS:"
echo "    DB_USERNAME    = $DB_USERNAME"
echo "    DB_PASSWORD    = $DB_PASSWORD"
echo "    DB_DATABASE    = $DB_DATABASE"
echo "    TEST_SIZE      = $TEST_SIZE (`printf "%'.f" $ROW_CNT` rows / session)"
echo "    SESSION_START  = `printf "%'.f" $SESSION_START`"
echo "    SESSION_STOP   = `printf "%'.f" $SESSION_STOP`"
echo "    SESSION_INCR   = $SESSION_INCR"
echo "    RUN_TIME       = `printf "%'.f" $RUN_TIME` (seconds)"
echo "    PLOT_DATA      = $PLOT_DATA"
echo "    DEF_TSP        = $DEF_TSP"
echo "    AWR_SNAP       = $AWR_SNAP"
echo "    AWR_BASE       = $AWR_BASE"
echo ""
echo "==================================================================="
echo ""

}

#==============================================================================================================

function test_plot () {
if ( ! type $PLOT_TOOL > /dev/null 2>&1 )
then
    exit 0
else

    exit 1
fi
}

#==============================================================================================================

function test_plot_version () {
PLOT_VER1=`$PLOT_TOOL --version | cut -d\. -f1 | cut -d' ' -f2`
PLOT_VER2=`$PLOT_TOOL --version | cut -d\. -f2 | cut -d' ' -f1`
if [ "$PLOT_VER1" -lt "4" ]
then
    exit 0
else
    if [ "$PLOT_VER2" -lt "2" ]
    then
        exit 0
    else
        exit 1
    fi
fi
}

#==============================================================================================================

function test_command () {
if ( ! type $CMD_TOOL > /dev/null 2>&1 )
then
    exit 0
else
    exit 1
fi
}

#==============================================================================================================

function test_connect () {
SQL_CMD="$CMD_TOOL -L -S $DB_USERNAME/$DB_PASSWORD@$DB_DATABASE"
$SQL_CMD <<EOF > /dev/null 2>&1
select * from dual;
EOF
return $?
}

#==============================================================================================================

function plot_data () {

gnuplot <<EOF > /dev/null 2>&1
set terminal jpeg
set grid y
set grid x
set key outside

#----------------------------------------------

set title  "DBBENCHMARK: SAR IO Throughput"
set xlabel "# Concurrent Users"
set xrange [-1:*]
set ylabel "Transactions/Second"
set yrange [0:*]

set style data histograms
set style histogram rowstacked
set style fill solid border
set boxwidth .5

set output '$REPORT_IO_JPG'
plot '$REPORT_IO_LOG' u 2:xtic(1) t "read_tps", '' u 3 t "write_tps"

#----------------------------------------------

set title  "DBBENCHMARK: SAR CPU Utilization"
set xlabel "# Concurrent Users"
set xrange [-1:*]
set ylabel "Precent CPU Usage"
set yrange [0:100]

set style data histograms
set style histogram rowstacked
set style fill solid border
set boxwidth .5

set output '$REPORT_CPU_JPG'
plot '$REPORT_CPU_LOG' u 2:xtic(1) t "%user", '' u 3 t "%nice", '' u 4 t "%system", '' u 5 t "%iowait"

#----------------------------------------------

set title  "DBBENCHMARK: SAR RAM Utilization"
set xlabel "# Concurrent Users"
set xrange [-1:*]
set ylabel "Precent RAM Usage"
set yrange [0:100]

set style data histograms
set style histogram
set style fill solid border
set boxwidth .5

set output '$REPORT_RAM_JPG'
plot '$REPORT_RAM_LOG' u 2:xtic(1) t "%mem_used"

#----------------------------------------------

set title  "DBBENCHMARK: SAR RUN QUEUE Utilization"
set xlabel "# Concurrent Users"
set xrange [-1:*]
set ylabel "Run Queue Depth"
set yrange [0:*]

set style data histograms
set style histogram
set style fill solid border
set boxwidth .5

set output '$REPORT_QUE_JPG'
plot '$REPORT_QUE_LOG' u 2:xtic(1) t "run_queue"

#----------------------------------------------
set title  "DBBENCHMARK: ORACLE TPS & IOPS"
set xlabel "# Concurrent Users"
set xrange [0:*]
set ylabel "Database Workload"
set yrange [0:*]

set style data linespoints
set style line
set pointsize 2

set output '$REPORT_IOPS2_JPG'
plot '$REPORT_IOPS2_LOG' using 2:xtic(1) t "TPS",    '' using 3 t "IOPS"
EOF

if [ $? -ne 0 ]; then return $?; fi

return $?
}

#==============================================================================================================

function test_results () {

echo ""
echo "==================================================================="
echo ""
echo "RESULTS:"

tail -q -n 1 $REPORT_LEAD*"_SESSIONS_SAR_IO.log" > $REPORT_IO_TMP
awk -v XSTART=$SESSION_START -v XINCR=$SESSION_INCR 'BEGIN{print "#users\t\tread_tps\t\twrite_tps"}{printf "%s\t\t%s\t\t%s\n",XSTART,$3,$4;XSTART+=XINCR}' < $REPORT_IO_TMP 1> $REPORT_IO_LOG 2>/dev/null
rm $REPORT_IO_TMP

tail -q -n 1 $REPORT_LEAD*"_SESSIONS_SAR_CPU.log" > $REPORT_CPU_TMP
awk -v XSTART=$SESSION_START -v XINCR=$SESSION_INCR 'BEGIN{print "#users\t\t%user\t\t%nice\t\t%system\t\t%iowait"}{printf "%s\t\t%s\t\t%s\t\t%s\t\t%s\n",XSTART,$3,$4,$5,$6;XSTART+=XINCR}' < $REPORT_CPU_TMP 1> $REPORT_CPU_LOG 2>/dev/null
rm $REPORT_CPU_TMP

tail -q -n 1 $REPORT_LEAD*"_SESSIONS_SAR_RAM.log" > $REPORT_RAM_TMP
awk -v XSTART=$SESSION_START -v XINCR=$SESSION_INCR 'BEGIN{print "#users\t\t%mem_used"}{printf "%s\t\t%s\n",XSTART,$4;XSTART+=XINCR}' < $REPORT_RAM_TMP 1> $REPORT_RAM_LOG 2>/dev/null
rm $REPORT_RAM_TMP

tail -q -n 1 $REPORT_LEAD*"_SESSIONS_SAR_QUE.log" > $REPORT_QUE_TMP
awk -v XSTART=$SESSION_START -v XINCR=$SESSION_INCR 'BEGIN{print "#users\t\trun_queue"}{printf "%s\t\t%s\n",XSTART,$2;XSTART+=XINCR}' < $REPORT_QUE_TMP 1> $REPORT_QUE_LOG 2>/dev/null
rm $REPORT_QUE_TMP

echo ""
echo $REPORT_IO_LOG
cat  $REPORT_IO_LOG

echo ""
echo $REPORT_CPU_LOG
cat  $REPORT_CPU_LOG

echo ""
echo $REPORT_RAM_LOG
cat  $REPORT_RAM_LOG

echo ""
echo $REPORT_QUE_LOG
cat  $REPORT_QUE_LOG

echo ""
echo "==================================================================="

if [ "$PLOT_DATA" = "Y" ]
then
    plot_data
fi

$SQL_CMD <<EOF > $REPORT_IOPS2_LOG 2>&1
set verify off
set feedback off
set linesize 256
set pagesize 0
set trimout on
set trimspool on

column session_cnt   format    99999    heading '#USERS'
column trans_sec     format 99999999    heading 'TPS'
column tot_iops      format 99999999    heading 'IOPS'

select session_cnt,
       round(trans_cnt/((timer_stop-timer_start)*24*60*60),0) trans_sec,
       ROUND(((sma_reads2-sma_reads1)+(sma_writes2-sma_writes1)+
              (lrg_reads2-lrg_reads1)+(lrg_writes2-lrg_writes1))/(timer_stop-timer_start)/86400,0) tot_iops
from DBBENCHMARK_RESULTS
order by session_cnt;
EOF
if [ $? -ne 0 ]; then return $?; fi

$SQL_CMD <<EOF > $REPORT_IOPS1_LOG 2>&1
set verify off
set feedback off
set linesize 256
set pagesize 999
set trimout on
set trimspool on

column test_name     format a44           heading 'TEST NAME'
column session_cnt   format 999,999       heading 'SESSION|COUNT'
column run_time      format a8            heading 'RUN TIME|HH:MM:SS'
column trans_cnt     format 99,999,999    heading 'TOTAL|TRANS|COUNT'
column trans_sec     format 99,999,999    heading 'TRANS|PER|SECOND'

column tby_read      format 99,999,999    heading 'TOTAL|READ|MB'
column tby_writes    format 99,999,999    heading 'TOTAL|WRITE|MB'
column tr_mbps       format 99,999,999    heading 'TOTAL|READ|MB/S'
column tw_mbps       format 99,999,999    heading 'TOTAL|WRITE|MB/S'
column tot_mbps      format 99,999,999    heading 'TOTAL|RE/WR|MB/S'
column tr_iops       format 99,999,999    heading 'TOTAL|READ|IOPS'
column tw_iops       format 99,999,999    heading 'TOTAL|WRITE|IOPS'
column tot_iops      format 99,999,999    heading 'TOTAL|RE/WR|IOPS'

column sma_reads     format 99,999,999    heading 'SMALL|READ|COUNT'
column sma_writes    format 99,999,999    heading 'SMALL|WRITE|COUNT'
column sma_total     format 99,999,999    heading 'SMALL|TOTAL|COUNT'
column sr_iops       format 99,999,999    heading 'SMALL|READ|IOPS'
column sw_iops       format 99,999,999    heading 'SMALL|WRITE|IOPS'
column st_iops       format 99,999,999    heading 'SMALL|TOTAL|IOPS'

column lrg_reads     format 99,999,999    heading 'LARGE|READ|COUNT'
column lrg_writes    format 99,999,999    heading 'LARGE|WRITE|COUNT'
column lrg_total     format 99,999,999    heading 'LARGE|TOTAL|COUNT'
column lr_iops       format 99,999,999    heading 'LARGE|READ|IOPS'
column lw_iops       format 99,999,999    heading 'LARGE|WRITE|IOPS'
column lt_iops       format 99,999,999    heading 'LARGE|TOTAL|IOPS'

select test_name, session_cnt,
       floor((timer_stop-timer_start )*24)
       || ':' ||
       mod(floor((timer_stop-timer_start )*24*60),60)
       || ':' ||
       mod(floor((timer_stop-timer_start)*24*60*60),60) run_time,
       trans_cnt,
       round(trans_cnt/((timer_stop-timer_start)*24*60*60),0) trans_sec,
       ROUND(((tby_reads2-tby_reads1)+
              (tby_writes2-tby_writes1))/1048576/(timer_stop-timer_start)/86400,0) tot_mbps,
       ROUND(((sma_reads2-sma_reads1)+(sma_writes2-sma_writes1)+
              (lrg_reads2-lrg_reads1)+(lrg_writes2-lrg_writes1))/(timer_stop-timer_start)/86400,0) tot_iops
from DBBENCHMARK_RESULTS
order by test_name;

select test_name, session_cnt,
       floor((timer_stop-timer_start )*24)
       || ':' ||
       mod(floor((timer_stop-timer_start )*24*60),60)
       || ':' ||
       mod(floor((timer_stop-timer_start)*24*60*60),60) run_time,
       ROUND((tby_reads2-tby_reads1)/1048576,0)         tby_read,
       ROUND((tby_writes2-tby_writes1)/1048576,0)       tby_writes,
       ROUND((tby_reads2-tby_reads1)/1048576/(timer_stop-timer_start)/86400,0)   tr_mbps,
       ROUND((tby_writes2-tby_writes1)/1048576/(timer_stop-timer_start)/86400,0) tw_mbps,
       ROUND(((tby_reads2-tby_reads1)+
              (tby_writes2-tby_writes1))/1048576/(timer_stop-timer_start)/86400,0) tot_mbps,
       ROUND(((sma_reads2-sma_reads1)+(lrg_reads2-lrg_reads1))/(timer_stop-timer_start)/86400,0)   tr_iops,
       ROUND(((sma_writes2-sma_writes1)+(lrg_writes2-lrg_writes1))/(timer_stop-timer_start)/86400,0) tw_iops,
       ROUND(((sma_reads2-sma_reads1)+(sma_writes2-sma_writes1)+
              (lrg_reads2-lrg_reads1)+(lrg_writes2-lrg_writes1))/(timer_stop-timer_start)/86400,0) tot_iops
from DBBENCHMARK_RESULTS
order by test_name;

select test_name, session_cnt,
       floor((timer_stop-timer_start )*24)
       || ':' ||
       mod(floor((timer_stop-timer_start )*24*60),60)
       || ':' ||
       mod(floor((timer_stop-timer_start)*24*60*60),60)  run_time,
       sma_reads2-sma_reads1                             sma_reads,
       sma_writes2-sma_writes1                           sma_writes,
       (sma_reads2-sma_reads1)+(sma_writes2-sma_writes1) sma_total,
       ROUND((sma_reads2-sma_reads1)/(timer_stop-timer_start)/86400,0)   sr_iops,
       ROUND((sma_writes2-sma_writes1)/(timer_stop-timer_start)/86400,0) sw_iops,
       ROUND(((sma_reads2-sma_reads1)+(sma_writes2-sma_writes1))/(timer_stop-timer_start)/86400,0) st_iops
from DBBENCHMARK_RESULTS
order by test_name;

select test_name, session_cnt,
       floor((timer_stop-timer_start )*24)
       || ':' ||
       mod(floor((timer_stop-timer_start )*24*60),60)
       || ':' ||
       mod(floor((timer_stop-timer_start)*24*60*60),60)  run_time,
       lrg_reads2-lrg_reads1                             lrg_reads,
       lrg_writes2-lrg_writes1                           lrg_writes,
       (lrg_reads2-lrg_reads1)+(lrg_writes2-lrg_writes1) lrg_total,
       ROUND((lrg_reads2-lrg_reads1)/(timer_stop-timer_start)/86400,0)   lr_iops,
       ROUND((lrg_writes2-lrg_writes1)/(timer_stop-timer_start)/86400,0) lw_iops,
       ROUND(((lrg_reads2-lrg_reads1)+(lrg_writes2-lrg_writes1))/(timer_stop-timer_start)/86400,0) lt_iops
from DBBENCHMARK_RESULTS
order by test_name;
EOF
if [ $? -ne 0 ]; then return $?; fi

echo ""
echo $REPORT_IOPS2_LOG
cat  $REPORT_IOPS2_LOG
echo ""
echo "==================================================================="

if [ "$AWR_SNAP" = "Y" ]
then
SQL_CMD <<EOF >> $REPORT_IOPS1_LOG 2>&1
set verify off
set feedback off
set linesize 256
set pagesize 999
set trimout on
set trimspool on

column baseline_name       format a40
column begin_interval_time format a25
column end_interval_time   format a25

select baseline_id, baseline_name, start_snap_id, end_snap_id
  from dba_hist_baseline
  where baseline_name like '$TEST_NAME%'
  order by baseline_id;
select snap_id, begin_interval_time, end_interval_time, snap_level, error_count
  from dba_hist_snapshot
  where snap_id in (select start_snap_id
                      from dba_hist_baseline
                      where baseline_name like '$TEST_NAME%')
     or snap_id in (select end_snap_id
                      from dba_hist_baseline
                      where baseline_name like '$TEST_NAME%')
  order by snap_id;
EOF
if [ $? -ne 0 ]; then return $?; fi
fi

return $?
}

#==============================================================================================================

function test_init () {

echo "WORKING: ....Create DBBENCHMARK_RESULTS performance measurement table"
$SQL_CMD <<EOF > /dev/null 2>&1
drop table DBBENCHMARK_RESULTS;
create table DBBENCHMARK_RESULTS
(
  test_name    varchar2(44)  not null primary key,
  session_cnt  number  not null,
  trans_cnt    number  not null,
  timer_start  date    not null,
  timer_stop   date        null,
  lrg_reads1   number  not null, -- 'physical read total multi block requests'
  lrg_writes1  number  not null, -- 'physical write total multi block requests'
  sma_reads1   number  not null, --  Total Reads - Large Reads
  sma_writes1  number  not null, --  Total Writes - Large Writes
  tby_reads1   number  not null, -- 'physical read total bytes'
  tby_writes1  number  not null, -- 'physical write total multi block requests'
  lrg_reads2   number      null, -- 'physical read total multi block requests'
  lrg_writes2  number      null, -- 'physical write total multi block requests'
  sma_reads2   number      null, --  Total Reads - Large Reads
  sma_writes2  number      null, --  Total Writes - Large Writes
  tby_reads2   number      null, -- 'physical read total bytes'
  tby_writes2  number      null  -- 'physical write total multi block requests'
);
EOF
if [ $? -ne 0 ]; then return $?; fi

echo "WORKING: ....Create DBBENCHMARK_TEST benchmark table & initial load data"
$SQL_CMD <<EOF > /dev/null 2>&1
drop table DBBENCHMARK_TEST purge;
CREATE TABLE DBBENCHMARK_TEST
(
    sid NUMBER
  , rid NUMBER
  , c01 VARCHAR2($COL_LENGTH)
  , c02 VARCHAR2($COL_LENGTH)
  , c03 VARCHAR2($COL_LENGTH)
  , c04 VARCHAR2($COL_LENGTH)
  , c05 VARCHAR2($COL_LENGTH)
  , c06 VARCHAR2($COL_LENGTH)
  , c07 VARCHAR2($COL_LENGTH)
  , c08 VARCHAR2($COL_LENGTH)
  , c09 VARCHAR2($COL_LENGTH)
  , c10 VARCHAR2($COL_LENGTH)
) TABLESPACE $DEF_TSP;
create or replace procedure DBBENCHMARK_LOADDATA
is
v_sid  PLS_INTEGER   := $SESSION_START;
v_rid  PLS_INTEGER   := 1;
v_xxx  VARCHAR2($COL_LENGTH) := RPAD('X',$COL_LENGTH);
v_yyy  VARCHAR2($COL_LENGTH) := RPAD('Y',$COL_LENGTH);
v_zzz  VARCHAR2($COL_LENGTH) := RPAD('Z',$COL_LENGTH);
begin
while (v_sid <= $SESSION_STOP) loop
  v_sid := v_sid + 1;
  while (v_rid <= $ROW_CNT) loop
    v_rid := v_rid + 1;
    INSERT INTO DBBENCHMARK_TEST
        VALUES (v_sid, v_rid,
                v_xxx, v_yyy, v_zzz, v_xxx, v_yyy, v_zzz, v_xxx, v_yyy, v_zzz, v_xxx);
    IF ( MOD( v_rid, 100 ) = 0 ) THEN
        COMMIT;
    END IF;
  end loop;
  COMMIT;
end loop;
COMMIT;
END;
/
execute DBBENCHMARK_LOADDATA;
EOF
if [ $? -ne 0 ]; then return $?; fi

echo "WORKING: Create DBBENCHMARK_TEST table's sole non-unique index"
$SQL_CMD <<EOF > /dev/null 2>&1
CREATE INDEX DBBENCHMARK_TEST_IDX1 ON DBBENCHMARK_TEST(sid, rid);
EOF
if [ $? -ne 0 ]; then return $?; fi

echo "WORKING: ....Create DBBENCHMARK_WORKLOAD procedure to call/execute"
$SQL_CMD <<EOF > /dev/null 2>&1
create or replace procedure DBBENCHMARK_WORKLOAD(p_sid in integer, p_run_time in integer, p_test_name varchar)
is
v_min      integer;
v_max      integer;
v_chunk    integer       := $BATCH_SIZE;
v_control  integer;
v_trx_cnt  integer       := 0;
v_date1    date          := SYSDATE;
v_date2    date          := v_date1;
v_aaa      varchar2($COL_LENGTH) := RPAD('A',$COL_LENGTH);
v_bbb      varchar2($COL_LENGTH) := RPAD('B',$COL_LENGTH);
v_ccc      varchar2($COL_LENGTH) := RPAD('C',$COL_LENGTH);
v_cnt      integer;
begin
while ((v_date2-v_date1)*86400 < p_run_time) loop
    select MIN(rid) into v_min from DBBENCHMARK_TEST where sid=p_sid;
    select MAX(rid) into v_max from DBBENCHMARK_TEST where sid=p_sid;
    v_control := DBMS_RANDOM.VALUE(1,8);
    CASE v_control
    WHEN 1 THEN
        UPDATE DBBENCHMARK_TEST SET
            c01 = DBMS_RANDOM.STRING('X',$COL_LENGTH),
            c10 = DBMS_RANDOM.STRING('X',$COL_LENGTH)
            WHERE (sid = p_sid and rid = v_min
                   or
                   sid = p_sid and rid = v_max);
        v_trx_cnt := v_trx_cnt + 1;
    WHEN 2 THEN
        UPDATE DBBENCHMARK_TEST SET
            c01 = DBMS_RANDOM.STRING('X',$COL_LENGTH),
            c10 = DBMS_RANDOM.STRING('X',$COL_LENGTH)
            WHERE (sid = p_sid and rid between v_min and v_min+v_chunk
                   or
                   sid = p_sid and rid between v_max-v_chunk and v_max);
        v_trx_cnt := v_trx_cnt + 1;
    WHEN 3 THEN
        UPDATE DBBENCHMARK_TEST SET
            c01 = DBMS_RANDOM.STRING('X',$COL_LENGTH),
            c10 = DBMS_RANDOM.STRING('X',$COL_LENGTH)
            WHERE (sid = p_sid and rid = v_min
                   or
                   sid = p_sid and rid = v_max);
        v_trx_cnt := v_trx_cnt + 1;
    WHEN 4 THEN
        UPDATE DBBENCHMARK_TEST SET
            c01 = DBMS_RANDOM.STRING('X',$COL_LENGTH),
            c10 = DBMS_RANDOM.STRING('X',$COL_LENGTH)
            WHERE (sid = p_sid and rid between v_min and v_min+v_chunk
                   or
                   sid = p_sid and rid between v_max-v_chunk and v_max);
        v_trx_cnt := v_trx_cnt + 1;
    WHEN 5 THEN
        DELETE FROM DBBENCHMARK_TEST
            WHERE (sid = p_sid and rid = v_min
                   or
                   sid = p_sid and rid = v_max);
        v_trx_cnt := v_trx_cnt + 1;
    WHEN 6 THEN
        DELETE FROM DBBENCHMARK_TEST
            WHERE (sid = p_sid and rid between v_min and v_min+v_chunk
                   or
                   sid = p_sid and rid between v_max-v_chunk and v_max);
        v_trx_cnt := v_trx_cnt + 1;
    WHEN 7 THEN
        INSERT INTO DBBENCHMARK_TEST
            VALUES (p_sid, v_min-1,
                    v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa);
        INSERT INTO DBBENCHMARK_TEST
            VALUES (p_sid, v_max+1,
                    v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa);
        v_trx_cnt := v_trx_cnt + 2;
    WHEN 8 THEN
        v_cnt:=0;
        while (v_cnt < v_chunk) loop
            v_cnt := v_cnt + 1;
            INSERT INTO DBBENCHMARK_TEST
                VALUES (p_sid, v_min-v_cnt,
                        v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa);
        end loop;
        v_cnt:=0;
        while (v_cnt < v_chunk) loop
            v_cnt := v_cnt + 1;
            INSERT INTO DBBENCHMARK_TEST
                VALUES (p_sid, v_max+v_cnt,
                        v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa, v_bbb, v_ccc, v_aaa);
        end loop;
        v_trx_cnt := v_trx_cnt + (2 * v_chunk);
    END CASE;
    COMMIT;
    v_date2:=SYSDATE;
end loop;
commit;
update DBBENCHMARK_RESULTS
  set trans_cnt = trans_cnt + v_trx_cnt
  where test_name = p_test_name;
commit;
END;
/
EOF
if [ $? -ne 0 ]; then return $?; fi

return $?
}

#==============================================================================================================

function test_workload () {
###echo "....call DBBENCHMARK_WORKLOAD($SESSION_CNT,$RUN_TIME,$TEST_NAME)"
$SQL_CMD <<EOF > /dev/null 2>&1
execute DBBENCHMARK_WORKLOAD($SESSION_CNT,$RUN_TIME,'$TEST_NAME');
EOF
if [ $? -ne 0 ]; then return $?; fi

return $?
}

#==============================================================================================================

function test_start () {

###echo "....resetting Oracle query cache...."
$SQL_CMD <<EOF > /dev/null 2>&1
ALTER SYSTEM FLUSH BUFFER_CACHE;
EOF
if [ $? -ne 0 ]; then return $?; fi

echo "WORKING: Capture DBBENCHMARK_RESULTS performance measurement start time"
$SQL_CMD <<EOF > /dev/null 2>&1
delete from DBBENCHMARK_RESULTS
    where test_name = '$TEST_NAME';
commit; 
insert into DBBENCHMARK_RESULTS
SELECT '$TEST_NAME', $SESSION_CUR, 0, sysdate, null,
  sum(decode(name,'physical read total multi block requests',value,0)),
  sum(decode(name,'physical write total multi block requests',value,0)),
  sum(decode(name,'physical read total IO requests',value,0)- decode(name,'physical read total multi block requests',value,0)),
  sum(decode(name,'physical write total IO requests',value,0)- decode(name,'physical write total multi block requests',value,0)),
  sum(decode(name,'physical read total bytes',value,0)),
  sum(decode(name,'physical write total bytes',value,0)),
  null, null, null, null, null, null
FROM gv\$sysstat;
commit;
EOF
if [ $? -ne 0 ]; then return $?; fi

if [ "$AWR_SNAP" = "Y" ]
then
    echo "WORKING: Capture the starting AWR snapshot performance measurement"
    AWR_SNAP1=`$SQL_CMD <<EOF
SET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF;
select to_char(DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT()) from dual;
EOF`
    if [ -z "$AWR_SNAP1" ]
    then
        echo "ERROR: Capture Could not determine start AWR snapshot id value"
    fi
fi

return $?
}

#==============================================================================================================

function test_stop () {

echo "WORKING: DBBENCHMARK_RESULTS performance measurement stop time"
$SQL_CMD <<EOF > /dev/null 2>&1
update DBBENCHMARK_RESULTS
set
(
  timer_stop,
  lrg_reads2,
  lrg_writes2,
  sma_reads2,
  sma_writes2,
  tby_reads2,
  tby_writes2
)
=
(
  SELECT sysdate,
    sum(decode(name,'physical read total multi block requests',value,0)),
    sum(decode(name,'physical write total multi block requests',value,0)),
    sum(decode(name,'physical read total IO requests',value,0)- decode(name,'physical read total multi block requests',value,0)),
    sum(decode(name,'physical write total IO requests',value,0)- decode(name,'physical write total multi block requests',value,0)),
    sum(decode(name,'physical read total bytes',value,0)),
    sum(decode(name,'physical write total bytes',value,0))
  FROM gv\$sysstat
)
where test_name = '$TEST_NAME';
commit;
EOF
if [ $? -ne 0 ]; then return $?; fi

if [ "$AWR_SNAP" = "Y" ]
then
    echo "WORKING: Capture the stopping AWR snapshot performance measurement"
    AWR_SNAP2=`$SQL_CMD <<EOF
SET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF;
select to_char(DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT()) from dual;
EOF`
    if [ -z "$AWR_SNAP2" ]
    then
        echo "ERROR: Capture Could not determine start AWR snapshot id value"
    fi
fi
if [ $? -ne 0 ]; then return $?; fi

### Create AWR Reports and Baseline
if [ "$AWR_SNAP" = "Y" ]
then
    V_DBID=`$SQL_CMD <<EOF
SET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF
select dbid into :V_DBID from v\\$database;
EOF`
    if [ $? -ne 0 ]; then return $?; fi

    V_INST=`$SQL_CMD <<EOF
SET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF
select instance_number into :V_INST from v\\$instance;
EOF`
    if [ $? -ne 0 ]; then return $?; fi

    AWR_REPORT=$REPORT_LEAD"_SESSIONS_`printf "%04d"$SESSION_CUR`_SNAPSHOTS_"$AWR_SNAP1"_"$AWR_SNAP2".txt"
    echo "WORKING: Generating text snapshot report: $AWR_REPORT"
    $SQL_CMD <<EOF > /dev/null 2>&1
        set trimout on;
        set trimspool on;
        spool $AWR_REPORT;
        SELECT output FROM TABLE (dbms_workload_repository.awr_report_text ($V_DBID, $V_INST, $AWR_SNAP1, $AWR_SNAP2));
        spool off;
EOF
    if [ $? -ne 0 ]; then return $?; fi

    AWR_REPORT=$REPORT_LEAD"_SESSIONS_`printf "%04d"$SESSION_CUR`_SNAPSHOTS_"$AWR_SNAP1"_"$AWR_SNAP2".html"
    echo "WORKING: Generating HTML snapshot report: $AWR_REPORT"
    $SQL_CMD <<EOF > /dev/null 2>&1
        set trimout on;
        set trimspool on;
        spool $AWR_REPORT;
        SELECT output FROM TABLE (dbms_workload_repository.awr_report_html ($V_DBID, $V_INST, $AWR_SNAP1, $AWR_SNAP2));
        spool off;
EOF
    if [ $? -ne 0 ]; then return $?; fi

    if [ "$AWR_BASE" = "Y" ]
    then
        echo "WORKING: Create AWR snapshot baseline for test run: $TEST_NAME"
        AWR_BASENUM=`$SQL_CMD <<EOF
SET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF
select DBMS_WORKLOAD_REPOSITORY.CREATE_BASELINE($AWR_SNAP1,$AWR_SNAP2,'$TEST_NAME') from dual;
EOF`
        if [ -z "$AWR_BASENUM" ]
        then
            echo "ERROR: Could not determine $TEST_NAME AWR baseline id value"
        fi
    else
        echo "WORKING: Dropping AWR snapshot range: $awr_snapshot1 - $awr_snapshot2"
        $SQL_CMD <<EOF > /dev/null 2>&1
            exec DBMS_WORKLOAD_REPOSITORY.DROP_SNAPSHOT_RANGE($AWR_SNAP1,$AWR_SNAP2);
EOF
        if [ $? -ne 0 ]; then return $?; fi
    fi
fi

return $?
}

#==============================================================================================================

function test_exec () {

TEST_NAME=$REPORT_NAME"_IOPS_`printf "%04d\n" $SESSION_CUR`"

test_start
if [ $? -ne 0 ]; then return $?; fi

sar -b $SAR_INT $SAR_CNT > $REPORT_LEAD"_`printf "%04d" $SESSION_CUR`_SESSIONS_SAR_IO.log" &
sar -u $SAR_INT $SAR_CNT > $REPORT_LEAD"_`printf "%04d" $SESSION_CUR`_SESSIONS_SAR_CPU.log" &
sar -r $SAR_INT $SAR_CNT > $REPORT_LEAD"_`printf "%04d" $SESSION_CUR`_SESSIONS_SAR_RAM.log" &
sar -q $SAR_INT $SAR_CNT > $REPORT_LEAD"_`printf "%04d" $SESSION_CUR`_SESSIONS_SAR_QUE.log" &

echo "WORKING: Executing `printf "%'.f" $SESSION_CUR` sessions against DBBENCHMARK_TEST table"
SESSION_CNT=1
while [ $SESSION_CNT -le $SESSION_CUR ]
do
    ( test_workload ) &
    SESSION_CNT=$[$SESSION_CNT+1]
done
echo "WORKING: ....Waiting on `printf "%'.f" $SESSION_CUR` sessions against DBBENCHMARK_TEST table"

wait

test_stop
if [ $? -ne 0 ]; then return $?; fi

return $?
}

#==============================================================================================================

function raise_error () {
echo ""
echo "==================================================================="
echo ""
echo "***ERROR*** $1: $2"
echo ""
echo "==================================================================="
echo ""
}

#==============================================================================================================
#========== Main body
#==============================================================================================================

set_defaults

if [ $# -eq 0 ]
then
    usage
    exit 1
fi

if [ $# -gt 0 ]
then
REQ_PARM_COUNT=0
# process parameters
while getopts "hu:u:p:d:z:s:S:i:r:P:T:a:b:" opt; do
    case $opt in
    h)
        usage
        exit 1
        ;;
    u)
        DB_USERNAME="$OPTARG"
        REQ_PARM_COUNT=$[$REQ_PARM_COUNT+1]
        ;;
    p)
        DB_PASSWORD="$OPTARG"
        REQ_PARM_COUNT=$[$REQ_PARM_COUNT+1]
        ;;
    d)
        DB_DATABASE="$OPTARG"
        REQ_PARM_COUNT=$[$REQ_PARM_COUNT+1]
        ;;
    z)
        TEST_SIZE="$OPTARG"
        ;;
    s)
        SESSION_START="$OPTARG"
        ;;
    S)
        SESSION_STOP="$OPTARG"
        ;;
    i)
        SESSION_INCR="$OPTARG"
        ;;
    r)
        RUN_TIME="$OPTARG"
        ;;
    P)
        PLOT_DATA="$OPTARG"
        ;;
    T)
        DEF_TSP="$OPTARG"
        ;;
    a)
        AWR_SNAP="$OPTARG"
        ;;
    b)
        AWR_BASE="$OPTARG"
        ;;
    \?)
        exit 1
        ;;
    esac
done
fi

if [ $REQ_PARM_COUNT -ne 3 ]
then
    raise_error "USAGE" "You must supply user name, password and database"
    exit 1
fi

TEST_SIZE=`echo $TEST_SIZE | tr 'a-z' 'A-Z'`
PLOT_DATA=`echo $PLOT_DATA | tr 'a-z' 'A-Z'`
AWR_SNAP=`echo $AWR_SNAP | tr 'a-z' 'A-Z'`
AWR_BASE=`echo $AWR_BASE | tr 'a-z' 'A-Z'`

case $TEST_SIZE in
SMALL)
    ROW_CNT=$SIZE_SMALL
    ;;
MEDIUM)
    ROW_CNT=$SIZE_MEDIUM
    ;;
LARGE)
    ROW_CNT=$SIZE_LARGE
    ;;
esac

# list working values
show_params

if [ "$TEST_SIZE" != "SMALL" -a "$TEST_SIZE" != "MEDIUM" -a "$TEST_SIZE" != "LARGE" ]
then
    raise_error "USAGE" "Test size must be either SMALL or MEDIUM or LARGE"
    exit 1
fi

if [ $SESSION_START -lt 1 ]
then
    raise_error "USAGE" "Sessions start must be >= 1"
    exit 1
fi

if [ $SESSION_STOP -lt $SESSION_START ]
then
    raise_error "USAGE" "Sessions stop must be >= sessions start"
    exit 1
fi

if [ $SESSION_INCR -lt 1 ]
then
    raise_error "USAGE" "Sessions increment by count must be >= 1"
    exit 1
fi

if [ $RUN_TIME -lt 10 ]
then
    raise_error "USAGE" "Run time must be >= 10 (seconds)"
    exit 1
fi

if [ "$PLOT_DATA" != "Y" -a "$PLOT_DATA" != "N" ]
then
    raise_error "USAGE" "Plot graphs of SAR data must be either Y or N"
    exit 1
fi
echo "WORKING: Testing for $PLOT_TOOL found executable in current \$PATH"
if ( ! test_plot )
then
    raise_error "ENV-PATH" "$PLOT_TOOL executable not found in current \$PATH"
    exit 1
fi
echo "WORKING: Testing for $PLOT_TOOL must minimally be version >= 4.2"
if ( ! test_plot_version )
then
    raise_error "VERSION" "$PLOT_TOOL disabled since it's version < 4.2"
    PLOT_DATA="N"
fi

if [ "$AWR_SNAP" != "Y" -a "$AWR_SNAP" != "N" ]
then
    raise_error "USAGE" "Collect AWR snapshots must be either Y or N"
    exit 1
fi

if [ "$AWR_BASE" != "Y" -a "$AWR_BASE" != "N" ]
then
    raise_error "USAGE" "Create AWR baseline must be either Y or N"
    exit 1
fi

echo "WORKING: Testing for $CMD_TOOL found executable in current \$PATH"
if ( ! test_command )
then
    raise_error "ENV-PATH" "$CMD_TOOL executable not found in current \$PATH"
    exit 1
fi

echo "WORKING: Testing connect to database with supplied parameters"
if ( ! test_connect )
then
    raise_error "DATABASE" "Cannot connect successfully to database with supplied parameters"
    exit 1
fi

rm -rf $REPORT_DIR
mkdir $REPORT_DIR

echo "WORKING: Processing steps for running benchmark test"
if ( test_init )
then
    SAR_INT=5
    SAR_CNT=$[($RUN_TIME/$SAR_INT)]
    SESSION_CUR=$SESSION_START
    while [ $SESSION_CUR -le $SESSION_STOP ]
    do
        test_exec
        SESSION_CUR=$[$SESSION_CUR+$SESSION_INCR]
    done
    test_results
    echo ""
    echo "WORKING: Zipping up test report directory and files into one zip file"
    zip $REPORT_DIR".zip" $REPORT_DIR/* > /dev/null 2>&1
fi

echo ""
echo "==================================================================="
echo ""
echo "ALLDONE: Processing successfully completed ..."
echo ""
echo "==================================================================="
echo ""

#==============================================================================================================
